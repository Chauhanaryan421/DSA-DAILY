public class ReversingAnArray {
    static  int [] reverse(int arr[],int size){
        int revarr[] =new int[5];
        int j =0;
        for(int i =size-1;i>=0;i--){

                revarr[j] = arr[i];
                j++;
        }
        return revarr;
    }

    public static void main(String[] args) {
        int arr []={1,2,3,4,5};
        for(int elements : arr){
            System.out.print(elements+" ");
        }
        System.out.println();
        int revarr [] = new int[5];
        revarr= reverse(arr,5);
        for(int elements : revarr){
            System.out.print(elements+" ");
        }
    }
}
