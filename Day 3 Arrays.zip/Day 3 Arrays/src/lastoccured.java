import java.util.Scanner;
public class lastoccured {
    static void input(int arr[], int size){
        Scanner inp = new Scanner(System.in);
        for(int i=0;i<size;i++){
            arr[i] = inp.nextInt();
        }
    }
    static void printArray(int arr[], int size){
        for(int i =0 ;i<size;i++){
            System.out.print(arr[i]);
        }
        System.out.println();
    }

    static int found(int arr[], int search){
        int index =-1;
        for(int i = 0; i< arr.length;i++){
            if(arr[i]==search){
                index = i;
            }
        }
        return index;
    }

    public static void main(String[] args) {
        System.out.println("Enter the element you want to search : ");
        Scanner inp = new Scanner(System.in);
        int search = inp.nextInt();

        System.out.println("Enter the size of your array : ");
        int size = inp.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter your array : ");
        input(arr,size);
        printArray(arr,size);
        int index = found(arr,search);
        System.out.println("The element "+search+" Last occured at : "+index);
    }
}
