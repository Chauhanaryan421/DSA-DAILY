import java.util.Scanner;

public class ArrayAssignment {
    static void input(int arr[], int size) {
        Scanner inp = new Scanner(System.in);
        for (int i = 0; i < size; i++) {
            arr[i] = inp.nextInt();
        }
    }
    static void printArray(int arr[], int size) {
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();

    }
    static boolean checkingpair(int arr[], int diff) {
        int diff2 = 0;
        boolean a = false;
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                diff2 = arr[j] - arr[i];
                if (diff == diff2) {
                    a = true;
                }
            }
        }
        return a;
    }
    public static void main(String[] args) {
        System.out.println("Enter your array size : ");
        Scanner input = new Scanner(System.in);
        int size = input.nextInt();
        int[] arr = new int[size];
        input(arr, size);
        printArray(arr, size);
        System.out.println("Enter your diff : ");
        int diff = input.nextInt();
        boolean ans = checkingpair( arr, diff);
        System.out.println(ans);
    }
}
