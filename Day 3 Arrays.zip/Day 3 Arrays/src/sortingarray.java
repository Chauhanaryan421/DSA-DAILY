import java.util.Arrays;

public class sortingarray {
    public static void main(String[] args) {
        int arr[] = {4, 3, 2, 6, 37, 8};
        Arrays.sort(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();

        System.out.println("Printing third smallest element : ");
        System.out.println(arr[2]); // kth smallest element = at k-1 index
        System.out.println("Printing third largest element : ");;
        System.out.println(arr[arr.length - 3]); // kth largest element  = at arr.length - k
    }
}
