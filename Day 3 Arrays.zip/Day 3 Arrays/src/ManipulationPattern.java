import java.util.Scanner;

public class ManipulationPattern {
    static void input(int arr[], int size){
        Scanner inp = new Scanner(System.in);
        for(int i=0;i<size;i++){
            arr[i] = inp.nextInt();
        }
    }
    static void printArray(int arr[], int size){
        for(int i =0 ;i<size;i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
    static void unique(int arr[], int size){
        for(int i =0 ;i<size;i++){
            for(int j =i + 1 ; j<size ; j++){
                if(arr[i] == arr[j]){
                    arr[i] = arr[j] = -1;
                }
            }
        }
        printArray(arr,size);
        for(int i = 0; i<size;i++){
            if(arr[i] != -1){
                System.out.println(arr[i] + " is a unique number at : " + i);
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("Enter your array size : ");
        Scanner input = new Scanner(System.in);
        int size =  input.nextInt();
        int [] arr = new int [size];
        input(arr,size);
        printArray(arr,size);
        unique(arr,size);
    }
}
