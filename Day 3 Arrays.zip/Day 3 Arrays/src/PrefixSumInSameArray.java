import java.sql.SQLOutput;
import java.util.Scanner;

public class PrefixSumInSameArray {
    static void printArray(int [] arr){
        int n = arr.length;
        int i = 0;
        while(i < n){
            System.out.print(arr[i] + " ");
            i++;
        }
        System.out.println();
    }

    static int [] makePrefixArray(int arr[] , int size){

        for(int i = 1 ; i<size;i++){
            arr[i] = arr[i-1] + arr[i];
        }
        return arr;
    }
    public static void main(String[] args) {
        System.out.println("Enter size of your array : ");
        Scanner input = new Scanner(System.in);
        int size = input.nextInt();

        System.out.println("Enter elements of your array : ");
        int [] arr = new int[size];
        for(int i = 0;i<size;i++){
            arr[i] = input.nextInt();
        }
        printArray(arr);

        int [] result = new int[size];
        result = makePrefixArray(arr,size);
        printArray(result);

    }
}
