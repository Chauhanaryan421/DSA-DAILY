import java.util.Scanner;

public class TargetSum_1 {
    static void input(int arr[], int size){
        Scanner inp = new Scanner(System.in);
        for(int i=0;i<size;i++){
            arr[i] = inp.nextInt();
        }
    }
    static void printArray(int arr[], int size){
        for(int i =0 ;i<size;i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
    static int findingpairs(int arr[],int sum){
        int ans=0;
        for(int i = 0 ;i < arr.length; i++){
            for(int j = i+ 1 ;j< arr.length;j++ ){
                for(int k = i+2 ;k< arr.length;k++){ // extra loop for calculating triplets count
                int sum2 = arr[i] + arr[j] + arr[k];
                if(sum == sum2) {
                    ans++;
                }
                }
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        System.out.println("Enter your array size : ");
        Scanner input = new Scanner(System.in);
        int size =  input.nextInt();
        int [] arr = new int [size];
        input(arr,size);
        printArray(arr,size);
        System.out.println("Enter your sum : ");
        int sum = input.nextInt();
        int ans = findingpairs(arr,sum);
        System.out.println(ans);



    }
}
