public class inplaceArrayReverse {
    static void swap(int[] arr){
        int n= arr.length;
        int j =n-1;
        int i = 0 ;
        while(i<j){
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            j--;
            i++;
        }
        for(int element : arr){
            System.out.print(element+" ");
        }
    }

    public static void main(String[] args) {
        int arr [] ={1,2,3,4,5,6};
        for(int element : arr){
            System.out.print(element+" ");
        }
        System.out.println();
        swap(arr);
    }
}
