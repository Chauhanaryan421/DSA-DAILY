import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;
class Swap{
    static int a ;
    static int b ;
    Swap(int a ,int b){
        this.a =a;
        this.b =b;
        System.out.println("a = "+a+" b= "+b);
    }

    static void swapping(){
        int temp;
        temp = a;
        a = b;
        b= temp;
        System.out.println("a = " +a+" b = "+b);
    }

}
public class Swap2numbers {


    public static void main(String[] args) {

        Swap s1 = new Swap(3, 5);
        Swap.swapping(); //agar bina dot ke call karna h toh Swap class mat banao aur poora code
                         //Swap2numbers m daal do usi class m static bina dot operator ke call
                         //kiya jaa sakta h
        }
}
