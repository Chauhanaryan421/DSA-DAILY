import java.util.Scanner;

public class FindSumFromLtoRInArray {
    static void printArray(int [] arr){


        for(int i = 1;i<=arr.length;i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
    static int [] makePrefixArray(int arr[] , int size){

        for(int i = 1 ; i<size;i++){
            arr[i] = arr[i-1] + arr[i];
        }
        return arr;
    }
    static int SumFromLtoR(int pref[] , int size){
        System.out.print("Enter the number of queries you have : ");
        Scanner input = new Scanner(System.in);
        int sum = 0 ;
        int q = input.nextInt();
        for(int  i = 0;i<q;i++){
            System.out.println("Enter your range i.e l and r : ");
            int l = input.nextInt();
            int r = input.nextInt();
            sum = pref[r] - pref[l-1];
        }
        return sum;
    }
    public static void main(String[] args) {
        System.out.println("Enter size of your array : ");
        Scanner input = new Scanner(System.in);
        int size = input.nextInt();

        System.out.println("Enter elements of your array : ");
        int [] arr = new int[size+1];
        for(int i = 1;i<=size;i++){
            System.out.print("a["+i+"] = ");
            arr[i] = input.nextInt();
            System.out.println();
        }
        System.out.println();
//        printArray(arr);
        int [] result = new int[size+1];
        result = makePrefixArray(arr,size);
        printArray(result);

        int sum = input.nextInt();
        sum = SumFromLtoR(result , size);
        System.out.println("The sum of your given range is : " + sum);


    }
}
