public class SortingSquares {
    static int [] sort(int arr[]){
        int left =0;
        int right = arr.length-1;
        int sorted[] =new int[arr.length];
        int k =0;
        while(left <= right){
            if(Math.abs(arr[left]) > Math.abs(arr[right])){
                sorted[k++] = arr[left] * arr[left];
                left++ ;
            }
            else{
                sorted[k++] = arr[right] * arr[right];
                right-- ;
            }
        }
        return sorted;
    }
    static void swap(int[] arr){
        int n= arr.length;
        int j =n-1;
        int i = 0 ;
        while(i<j){
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            j--;
            i++;
        }
        for(int element : arr){
            System.out.print(element+" ");
        }
    }

    public static void main(String[] args) {
        int arr[] ={ -10,-5,-3,1,4,2};
        for(int elements : arr){
            System.out.print(elements + " ");
        }
        System.out.println();
        int sorted [] =sort(arr);
        for(int elements : sorted){
            System.out.print(elements + " ");
        }
        System.out.println();
        swap(sorted);

    }

}
