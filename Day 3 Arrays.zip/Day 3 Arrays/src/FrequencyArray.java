import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;
public class FrequencyArray{
//    int arr[] = new int[7];
public static void main(String[] args) {
    int arr[] = {5, 6, 5, 400, 560, 100, 400};
    System.out.println("Enter number of queries : ");
    Scanner input = new Scanner(System.in);
    int q = input.nextInt();
    int[] freqarr = new int[701];

    for(int i =0 ; i<701 ; i++){
        freqarr[i] = 0;
    }

    int l=0;
    while(l<arr.length){
        int temp =arr[l];
        for(int k = 0;k<701;k++){
            freqarr[temp]++;
        }
        l++;
    }
    int a,j = 0;
    while(j<q){
        System.out.println("Enter the number you want to check : ");
        a = input.nextInt();
        if(freqarr[a] >0){
            System.out.println("Yes The number is present !");
        }
        else{
            System.out.println("Sorry The number is not present in the array !");
        }
        j ++;
    }
}

}
