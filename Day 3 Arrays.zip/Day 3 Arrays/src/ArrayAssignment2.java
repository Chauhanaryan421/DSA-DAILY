import java.util.Arrays;
import java.util.Scanner;

public class ArrayAssignment2 {
    static void input(int arr[], int size) {
        Scanner inp = new Scanner(System.in);
        for (int i = 0; i < size; i++) {
            arr[i] = inp.nextInt();
        }
    }
    static void printArray(int arr[], int size) {
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();

    }
    static void findmissing(int arr[], int size){
        Arrays.sort(arr);
        printArray(arr,size);
        for(int i =0 ; i<size;i++){
            if(arr[i+1] - arr[i] == 2){
                int a = i+2;
                System.out.println("The number missing is : " + a );
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("Enter your array size : ");
        Scanner input = new Scanner(System.in);
        int size = input.nextInt();
        int[] arr = new int[size];
        input(arr, size);
        printArray(arr, size);
        findmissing(arr,size);
    }
}
