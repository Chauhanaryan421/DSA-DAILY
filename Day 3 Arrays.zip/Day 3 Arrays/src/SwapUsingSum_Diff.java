public class SwapUsingSum_Diff {
    public static void main(String[] args) {
        int a =9;
        int b =3;
        System.out.println("before Swapping");
        System.out.println("a = "+a+" b = "+b);
        a = a+b;
        b = a-b;
        a = a - b;
        System.out.println("after Swapping");
        System.out.println("a = "+a+" b = "+b);

    }
}
