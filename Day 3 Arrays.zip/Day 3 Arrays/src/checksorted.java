import java.util.Scanner;
public class checksorted {
    static void input(int arr[], int size){
        Scanner inp = new Scanner(System.in);
        for(int i=0;i<size;i++){
            arr[i] = inp.nextInt();
        }
    }
    static void printArray(int arr[], int size){
        for(int i =0 ;i<size;i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    static boolean sorted(int arr[],int size){
        boolean check = true;
        for(int i = 1 ;i<size;i++){
            if(arr[i-1] > arr[i]){
                check = false;
            }

        }
        return check;
    }
    public static void main(String[] args) {
        System.out.println("Enter the element you want to search : ");
        Scanner inp = new Scanner(System.in);
        int search = inp.nextInt();

        System.out.println("Enter the size of your array : ");
        int size = inp.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter your array : ");
        input(arr,size);
        printArray(arr,size);

        boolean ans = sorted(arr , size);
        System.out.println(ans);
    }
}
