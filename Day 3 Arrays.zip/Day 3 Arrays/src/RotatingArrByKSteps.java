public class RotatingArrByKSteps {
    static int[] rotate(int arr[],int k){
        int n = arr.length-1;
        int j=0;
        while(j<k) {
            int temp = arr[n];
            for (int i = n; i >0 ; i--) {
                arr[i] = arr[i - 1];
            }
            arr[0] = temp;
            j++;
        }
        return arr;

    }

    public static void main(String[] args) {
        int arr[]={ 1,2,3,4,5,6};
        for(int elements : arr){
            System.out.print(elements + " ");
        }
        System.out.println();
        int k =12;
        int ans[] = new int[6];
        ans = rotate(arr,k);
        for(int elements : ans){
            System.out.print(elements + " ");
        }
    }
}
