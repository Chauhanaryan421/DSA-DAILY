import java.util.Scanner;
public class linearsearch {
    public static void main(String[] args) {
        System.out.println("Enter your size of array : ");
        Scanner input = new Scanner(System.in);
        int size = input.nextInt();
        int[] age = new int[size];
        for (int i = 0; i < size; i++) {
            System.out.print("age[" + i + "] = ");
            age[i] = input.nextInt();
        }
        for (int i = 0; i < size; i++) {
            System.out.println(age[i]);

        }
        System.out.println("Enter the number you want to search : ");
        int search = input.nextInt();
        for(int i = 0; i<size;i++){
            if(age[i] == search){
                System.out.println(age[i]+" Age found at index "+i);
                break;
            }
        }
    }
}