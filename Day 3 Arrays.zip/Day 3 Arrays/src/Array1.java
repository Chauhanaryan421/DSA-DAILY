public class Array1 {
    public static void main(String[] args) {
//        int age[] = new int [3];
//        age[0]= 1;
//        age[1]=3;
//        age[2]=5;
        int age[] = {1,3,5,2,6,7};
//        for(int i =0;i<age.length;i++){
//            System.out.println(age[i]);
//        }
        for(int i : age){

        }

    }
}
