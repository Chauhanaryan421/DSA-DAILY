public class ArraySort0_1 {
    static int [] Sort(int arr[]){
        int j =arr.length - 1;
        int i =0;
        while(i<j){
            if(arr[i] %2 == 0) i++;
            if(arr[j] % 2 != 0) j--;

            if(i<j && arr[i] % 2 !=0  &&  arr[j] %2 ==0){
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                i++;
                j--;
            }

        }
        return arr;
    }
    public static void main(String[] args) {
        int arr[]={1,3,4,5,6};
        for(int elements : arr){
            System.out.print(elements + " ");
        }
        System.out.println();
        int sortedarray[] = new int[arr.length];
        sortedarray = Sort(arr);
        for(int elements : sortedarray){
            System.out.print(elements + " ");
        }





    }
}
