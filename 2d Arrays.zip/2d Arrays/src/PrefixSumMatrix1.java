import java.util.Scanner;

public class PrefixSumMatrix1 {
    static void calculatePrefixMatrix(int [][] arr){
        int r= arr.length;
        int c = 0;
        if(r>0){
             c = arr[0].length;
        }
        for(int i = 0 ;i < r;i++){
            for(int j = 1;j < c;j++){
                arr[i][j] += arr[i][j-1];
            }
        }
    }
    static int findSum(int arr[][],int l1,int r1 , int l2 , int r2){
        int sum =0;
        calculatePrefixMatrix(arr);
        for(int i =l1;i<=l2;i++){
            sum+=arr[i][r2] - arr[i][r1-1];
        }
        return sum;
    }
    public static void main(String[] args) {
        System.out.println("Enter r and c : ");
        Scanner input = new Scanner(System.in);
        int r = input.nextInt();
        int c = input.nextInt();
        int [][] arr = new int[r][c];
        System.out.println("Enter you 2d array : ");
        for(int i = 0;i<r;i++){
            for(int j = 0;j<c;j++){
                arr[i][j] = input.nextInt();
            }
        }
        System.out.println("Enter boundaries l1,r1,l2,r2: ");
        int l1 = input.nextInt();
        int r1 = input.nextInt();
        int l2 = input.nextInt();
        int r2 = input.nextInt();
        System.out.println("The sum is : " + findSum(arr,l1,r1,l2,r2));
    }
}
