import java.util.Scanner;

public class PrefixSumMatrix2 {
    static void calculatePrefixMatrix(int [][] arr){
        int r= arr.length;
        int c = 0;
        if(r>0){
            c = arr[0].length;
        }
        for(int i = 0 ;i < r;i++){
            for(int j = 1;j < c;j++){
                arr[i][j] += arr[i][j-1];
            }
        }
        for(int j = 0 ;j < c;j++){
            for(int i = 1;i < r;i++){
                arr[i][j] += arr[i-1][j];
            }
        }
    }
    static int findSum(int arr[][],int l1,int r1 , int l2 , int r2){
        int sum =0 ; int left =0; int up = 0 ; int upleft=0;
        int ans = 0;
        calculatePrefixMatrix(arr);

        sum = arr[l2][r2];
        if(l1 > 1)
            up = arr[l1-1][r2];
        if(r1 > 1)
            left= arr[l2][r1-1];
        if(l1 > 1 && r1>1)
            upleft = arr[l1-1][r1-1];
        ans = sum - left - up + upleft;
        return ans;
    }
    public static void main(String[] args) {
        System.out.println("Enter r and c : ");
        Scanner input = new Scanner(System.in);
        int r = input.nextInt();
        int c = input.nextInt();
        int [][] arr = new int[r][c];
        System.out.println("Enter you 2d array : ");
        for(int i = 0;i<r;i++){
            for(int j = 0;j<c;j++){
                arr[i][j] = input.nextInt();
            }
        }
        System.out.println("Enter boundaries l1,r1,l2,r2: ");
        int l1 = input.nextInt();
        int r1 = input.nextInt();
        int l2 = input.nextInt();
        int r2 = input.nextInt();
        System.out.println("The sum is : " + findSum(arr,l1,r1,l2,r2));
    }
}
