import java.util.Scanner;

public class SpiralMatrix1 {
    static void printArray(int[][] arr, int r, int c) {
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }
    static void printSpiral(int[][] arr , int r,int c){
        int tr = 0,br = r-1,leftcol=0,rightcol = c-1;
        int totalElements =0;

        while(totalElements < r*c){
            for(int i = leftcol;i<=rightcol && totalElements < r*c;i++){
                System.out.print(arr[tr][i] + " ");
                totalElements++;
            }
            tr++;
            for(int i = tr;i<=br && totalElements < r*c;i++){
                System.out.print(arr[i][rightcol] + " ");
                totalElements++;
            }
            rightcol--;
            for(int i = rightcol;i>=leftcol && totalElements < r*c;i--){
                System.out.print(arr[br][i] + " ");
                totalElements++;
            }
            br--;
            for(int i = br;i>=tr && totalElements < r*c;i--){
                System.out.print(arr[i][leftcol] + " ");
                totalElements++;
            }
            leftcol++;
        }
    }

    public static void main(String[] args) {
        System.out.println("Enter no. of rows and columns : ");
        Scanner input = new Scanner(System.in);
        int r = input.nextInt();
        int c = input.nextInt();

        System.out.println("Enter your 2 d array : ");
        int[][] arr = new int[r][c];
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                arr[i][j] = input.nextInt();
            }
        }
        printArray(arr, r, c);
        printSpiral(arr,r,c);
    }

}
