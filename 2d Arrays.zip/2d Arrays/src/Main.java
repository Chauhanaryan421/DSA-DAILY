//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
   static void printArray(int [][]arr,int r,int c){
       for(int i = 0 ; i < r;i++){
           for(int j = 0 ; j < c; j++){
               System.out.print(arr[i][j] + " ");
           }
           System.out.println();
       }
   }
   static void multiply(int [][] arr1 , int r1,int c1,int [][]arr2 , int r2 , int c2){
       int [][] mul = new int[r1][c2];
       if(c1!= r2){
           System.out.println("Sorry no multiplication possible");
           return;
       }
       else{
           for(int i = 0 ; i<r1 ; i++){
               for(int j= 0;j<c2 ; j++){
                   for(int k = 0 ;k<c1 ; k++){
                       mul[i][j] += arr1[i][k] * arr2[k][j];
                   }
               }
           }
           printArray(mul,2,2);
       }
   }

    public static void main(String[] args) {
        int a[][] = {
                {1,2,3},
                {4,5,6}
        };
        int b[][] = {
                {3,2},
                {2,4},
                {7,8}
        };
        printArray(a,2,3);
        System.out.println();
        printArray(b,3,2);
        System.out.println();
        multiply(a,2,3,b,3,2);
    }
}
