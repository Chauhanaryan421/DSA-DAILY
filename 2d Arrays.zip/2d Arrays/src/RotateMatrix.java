import java.util.Scanner;

public class RotateMatrix {
    static void printArray(int[][] arr , int r , int c){
        for(int i = 0;i< r ;i++){
            for(int j =0;j<c;j++){
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }

    }
    static int [][] transpose(int arr [][] ,int r,int c){

        for(int i = 0;i< c ;i++){
            for(int j =i;j<r;j++){
                int temp = arr[i][j];
                arr[i][j] = arr[j][i];
                arr[j][i] = temp;
            }
        }
        return arr;
    }

    static void rotate(int[][] arr , int n){
        transpose(arr,n,n);
            for (int i =0 ;i<n;i++){
                reverse(arr[i]);
            }
    }
    static void reverse(int arr []){
        int i = 0;
        int j= arr.length-1;
        while(i<j){
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }

    }
    public static void main(String[] args) {
        System.out.println("Enter no. of rows and columns : ");
        Scanner input = new Scanner(System.in);
        int r = input.nextInt();
        int c = input.nextInt();

        System.out.println("Enter your 2 d array : ");
        int [][] arr = new int[r][c];
        for(int i = 0;i< r ;i++){
            for(int j =0;j<c;j++){
                arr[i][j] = input.nextInt();
            }
        }
        printArray(arr,r,c);

        rotate(arr,r);
        System.out.println();
        printArray(arr,r,c);
    }
}
